package upload.data;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@WebServlet("/UploadServlet")
@MultipartConfig()
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

        Part filePart = request.getPart("fileToUpload");

        
        if (filePart.getSize() == 0) {
            response.getWriter().println("No file uploaded!");
            return;
        } else if (!filePart.getContentType().startsWith("text/csv")) {
            response.getWriter().println("Only CSV files allowed!");
            return;
        }

        
        String fileName = filePart.getSubmittedFileName();
        InputStream fileContent = filePart.getInputStream();

        Connection connection = null;
        PreparedStatement statement = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/uploadfiles", "root", "root123");

            statement = connection.prepareStatement("INSERT INTO your uploaddata (NIC, Age, Gender, Birthday) VALUES (?, ?, ?, ?)");
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(fileContent));
            String line;
            while ((line = reader.readLine()) != null) {
                
                String[] data = line.split(",");

                
                for (int i = 0; i < data.length; i++) {
                    statement.setString(i + 1, data[i]);
                }

                statement.executeUpdate();
            }

            response.getWriter().println("CSV data uploaded successfully!");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); 
            response.getWriter().println("Error uploading data!");
        } finally {

            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                	
                    e.printStackTrace(); 
                }
            }
        }
    }


}
