package NicValid;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/NIC")
public class NIC extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		public static void processInput(String nic) {
			
	        if (nic.matches("[0-9]{9}[vVxX]$") || nic.matches("[0-9]{12}")) {
	            System.out.println("Input string matches at least one of the regex patterns.");
	            int[] days = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	            String birthDayString;
	            String gender;
	            String birthday;
	            int age;

	            if(nic.length() == 12) {
	                birthDayInt = Integer.parseInt(nic.substring(0, 7));
	            } else {
	                birthDayInt = Integer.parseInt("19" + nic.substring(0, 5));
	            }

	            String dayString = String.valueOf(birthDayInt).substring(Math.max(0, String.valueOf(birthDayInt).length() - 3));

	            int day = Integer.parseInt(dayString);

	            if(day >= 500){
	                gender = "Female";
	                day -= 500;
	            } else {
	                gender = "Male";
	            }
	            if(day <= 366) {
	                int month = 0;
	                int date = 0;

	                for(int i = 0; i < 12; i++) {
	                    day -= days[i];
	                    if(day <= days[i+1]) {
	                        month = i+2;
	                        date = day;
	                        break;
	                    }
	                }

	                birthday = birthDayInt + "-" + month + "-" + date;

	                LocalDate bd = LocalDate.parse(birthday);
	                age = Period.between(bd, LocalDate.now()).getYears();
	                System.out.println("Gender: " + gender);
	                System.out.println("Birthday: " + birthday);
	                System.out.println("Age: " + age);

	            } else {
	                System.out.println("Incorrect NIC");
	            }

	        } else {
	            System.out.println("Incorrect NIC");
	        }
		}
	}
}
